package ds4300_twitter;

import java.util.List;

public interface TwitterAPI {

  // posts tweet from Driver to API?
  void postTweet(Tweet t);

  /**
   * Gets the Tweets of the user of the given ID
   * @param userID index of given
   * @return
   */
  List<Tweet> getTimeline(int userID);

  /**
   * Gets the ID's of the followers of the user of the given ID.
   * @param userid index of the user whose followers are retrieved.
   * @return List of Integers representing ID's of followers.
   */
  List<Integer> getFollowers(Integer userid);

  /**
   * Gets tweet ID's of given user
   * @param userid index of user in question
   * @return List of Integers of ID's of tweets.
   */
  List<Integer> getTweets(Integer userid);

  /**
   *
   * @param userId
   * @param followsID
   */
  void addFollows(int userId, int followsID);

  void connect(String url, String user, String pw);

  void close();
}
