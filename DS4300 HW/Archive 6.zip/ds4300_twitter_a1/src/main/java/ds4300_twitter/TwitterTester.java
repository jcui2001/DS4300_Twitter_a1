package ds4300_twitter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class TwitterTester {

  public static void main(String[] args) {
    //Connection con = DriverManager.getConnection(jdbc:myDriver:myDatabase);
    TwitterAPI api = new MySQLTwitterAPI();
    String url = "jdbc:mysql://localhost:3306/twitter_a1?serverTimezone=EST5EDT";
    String user = System.getenv("TWITUSER");
    //TODO: Change this, you should NOT have your password hardcoded
    String pw = System.getenv("TWITPW");

/*
    List<Integer> users = api.getFollowers(3);
    System.out.println(users.size());
*/
    try {
      /*
      File tweetfile = new File("tweet.csv");
      Scanner readr = new Scanner(tweetfile);
      while (readr.hasNextLine()) {
        String data = readr.nextLine();
        System.out.println(data);
      }
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }
       */
      BufferedReader reader = new BufferedReader(new FileReader("/Users/jeremycui/Downloads/hw1_data/tweet.csv"));
      api.connect(url, user, pw);
      long start = System.currentTimeMillis();
      int count = 0;
      String currentLine;
      reader.readLine();
      while ((currentLine = reader.readLine()) != null) {
        String[] values = currentLine.split(",");
        int userId = Integer.parseInt(values[0]);
        String tweettx = values[1];
        count += 1;
        System.out.println(userId + ", " + tweettx);
        Tweet tweet = new Tweet(userId, tweettx);
        api.postTweet(tweet);
        System.out.println(count);
      }
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }

    try {
      Random rand = new Random();
      BufferedReader reader = new BufferedReader(new FileReader("/Users/jeremycui/Downloads/hw1_data/tweet.csv"));
      api.connect(url, user, pw);
      long start = System.currentTimeMillis();
      int count = 0;
      String currentLine;
      reader.readLine();
      int largestId = 0;
      while ((currentLine = reader.readLine()) != null) {
        String[] values = currentLine.split(",");
        int userId = Integer.parseInt(values[0]);
        String tweettx = values[1];

        if (userId > largestId) {
          largestId = userId;
        }
        count += 1;
        //System.out.println(userId + ", " + tweettx);
        int upbound = largestId;
        api.getTimeline(new Random)
      }
    } catch (IOException e) {
      System.out.println(e.getMessage());
    }

    List<Integer> tweetids = api.getTweets(5);
    System.out.println(tweetids);

    api.close();
  }
}
